﻿using System;

class HowOldYouWillBeAfter10Years
{
    static void Main()
    {
    }
}
