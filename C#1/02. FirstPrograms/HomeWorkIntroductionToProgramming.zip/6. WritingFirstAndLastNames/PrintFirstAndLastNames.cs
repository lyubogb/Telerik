﻿using System;

class PrintFirstAndLastNames
{
    static void Main()
    {
        string firstName = "Любомир";
        string lastName = "Стоянов";
        Console.WriteLine("Моето име е {0} {1}.\n",firstName, lastName);
    }
}
