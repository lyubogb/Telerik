﻿
using System;

class PrintMyName
{
    static void Main()
    {
        string firstName = "Lyubomir";
        string lastName = "Stoyanov";
        string firstNameCir = "Любомир";
        string lastNameCir = "Стоянов";
        string space = "  ";
        Console.WriteLine(firstName + space + lastName);
        Console.WriteLine(firstNameCir + space + lastNameCir);
    }
}
