﻿using System;

class Prit1_101_1001
{
    static void Main()
    {
        Console.WriteLine("1");
        Console.WriteLine("101");
        Console.WriteLine("1001");
        Console.WriteLine("or");
        Console.WriteLine("1 ," + "101 ," + "1001\n");
    }
}
