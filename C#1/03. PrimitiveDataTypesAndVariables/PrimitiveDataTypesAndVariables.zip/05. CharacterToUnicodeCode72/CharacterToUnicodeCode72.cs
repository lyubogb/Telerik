﻿using System;

class CharacterToUnicodeCode72
{
    static void Main()
    {
        char decVar = '\u0048';       // decimal code 0072 => 0x0048 or \u0048(Unicode)
        Console.WriteLine(decVar);
    }
}

