﻿using System;

class DeclareAndChangeOfValues
{
    static void Main()
    {
        Console.WriteLine("Enter Your first number");
        int valueA = int.Parse(Console.ReadLine());
        Console.WriteLine("Enter Your second number");
        int valueB = int.Parse(Console.ReadLine());
        Console.WriteLine("first number = {0}\nsecon number = {1}", valueA, valueB);
        valueA++;
        valueB = valueB * 3;
        Console.WriteLine("first number + 1 = {0}\nsecond number * 3 = {1}", valueA, valueB);
    }
}

