﻿

using System;


class CompareFloatingPointsValues
{
    static void Main()
    {
        
        decimal Precision = 0.000001m;
        decimal variableA ;
        decimal variableB ;
        decimal newVariableA;
        decimal newVariableB;
        bool result;
         
        Console.WriteLine("Enter variableA");
        variableA = decimal.Parse(Console.ReadLine());
        Console.WriteLine("Enter variableB");
        variableB = decimal.Parse(Console.ReadLine());
        
        newVariableA = Math.Round(variableA,6);
        newVariableB = Math.Round(variableB, 6);
        result = ((Math.Abs(newVariableA - newVariableB)) < Precision);
        Console.WriteLine("A = {0}", newVariableA);
        Console.WriteLine("B = {0}", newVariableB);

        Console.WriteLine("Result of  the comparison is {0}", result);

    }
}