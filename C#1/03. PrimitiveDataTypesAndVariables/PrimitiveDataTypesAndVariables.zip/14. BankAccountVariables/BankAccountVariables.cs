﻿using System;

class BankAccountVariables
{
    static void Main()
    {
        string firstName = null;
        string middleName = null;
        string lastName = null;
        decimal? balance = null;
        string bankName = null;
        int? IBAN = null;
        int? BICCode = null;
        decimal? cardBalance = null;
        decimal? firstCreditCardNum = null; 
        decimal? secondCreditCardNum = null;
        decimal? thirdCreditCardNum = null;
        
        firstName = "Ivan";
        middleName = "Ivanov";
        lastName = "Stoyanov";
        bankName = "CBCG";
        IBAN = 535185789;
        BICCode = 568497561;
        cardBalance = 15704;
        firstCreditCardNum = 300;
        secondCreditCardNum = 1589;
        thirdCreditCardNum = 1235;
        balance = (decimal)((int)cardBalance * 0.9);

        Console.WriteLine("Holder accound: {0} {1} {2}", firstName, middleName, lastName);
        Console.WriteLine("Balance: {0}", balance);
        Console.WriteLine("Bank name: {0}",bankName);
        Console.WriteLine("IBAN: {0}", IBAN);
        Console.WriteLine("BIC code: {0}", BICCode);
        Console.WriteLine("First credit card number: {0}", firstCreditCardNum);
        Console.WriteLine("Second credit card number : {0}", secondCreditCardNum);
        Console.WriteLine("Third credit card number : {0}", thirdCreditCardNum);
        Console.WriteLine("Card Balance: {0}", thirdCreditCardNum);
    }
}
