﻿using System;

class RepresentationHEXValue
{
    static void Main()
    {
        int val1 = 0xFE;
        Console.WriteLine((int)val1);
    }
}

