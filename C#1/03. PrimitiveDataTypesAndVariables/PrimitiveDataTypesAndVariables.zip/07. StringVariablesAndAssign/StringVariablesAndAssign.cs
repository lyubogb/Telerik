﻿using System;

class StringVariablesAndAssign
{
    static void Main()
    {
        string hello = "Hello";
        string world = "World";
        string thirdValue;
        object Full = null;
        Full = hello + " " + world;
        Console.WriteLine(Full);
        thirdValue = (string) Full;
        Console.WriteLine(thirdValue);
    }
}
