﻿using System;

class DeclarationVariablesOfEmployer
{
    static void Main()
    {
        string firstName;
        string familyName;
        byte age;
        char gender;
        uint IDNumber;
        uint uniqueEmployerNumber;
    }
}
