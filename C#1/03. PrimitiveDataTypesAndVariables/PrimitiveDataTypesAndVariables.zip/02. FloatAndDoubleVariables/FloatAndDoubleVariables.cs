﻿using System;

class FloatAndDoubleVariables
{
    static void Main()
    {
        float variable1 = 12.345f ;
        float variable2 = 3456.091f;
        double variable3 = 34.567839023;
        double variable4 = 8923.1234857;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}", variable1, variable2, variable3, variable4);
    }
}

