﻿using System;

class DeclareBooleanVariable
{
    static void Main()
    {
        bool? isFemale = null;
        byte midleReg;

        Console.WriteLine("Wat is Your gender? (Male-0 or Female-1)");
        midleReg = Byte.Parse(Console.ReadLine());
        if (midleReg == 1)
        {
            isFemale = true;
            Console.WriteLine("You are female.");
        }
        if (midleReg == 0)
        {
            isFemale = false;
            Console.WriteLine("You are male.");
        }
    }
}
