﻿// 13.
// * Write a program that sorts an array of integers using 
// the merge sort algorithm (find it in Wikipedia).

using System;

class Program
{

static void Main()
    {
       
    }
}

