﻿// 15.
// * Modify your last program and try to make it work for any number type,
//   not just integer (e.g. decimal, float, byte, etc.). Use generic method 
//   (read in Internet about generic methods in C#).


using System;

class Program
{
    static void Main()
    {

    }
}